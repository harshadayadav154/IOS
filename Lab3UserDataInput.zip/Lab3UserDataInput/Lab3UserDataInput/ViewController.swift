//
//  ViewController.swift
//  Lab3UserDataInput
//
//  Created by user235622 on 9/21/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBOutlet var firstNameTextField : UITextField!
    @IBOutlet var lastNameTextField : UITextField!
    @IBOutlet var countryTextField : UITextField!
    @IBOutlet var ageTextField : UITextField!
    @IBOutlet var textView : UITextView!
    @IBOutlet var messageLabel : UILabel!
    
    @IBAction func tapMade(_ sender : Any){
        if firstNameTextField.isFirstResponder {
            firstNameTextField.resignFirstResponder()
        }
        if lastNameTextField.isFirstResponder {
            lastNameTextField.resignFirstResponder()
        }
        if countryTextField.isFirstResponder {
            countryTextField.resignFirstResponder()
        }
        if ageTextField.isFirstResponder {
            ageTextField.resignFirstResponder()
        }
    }
    
    func showErrorMessage(_ message: String, _ color: String){
        messageLabel.text = message
        messageLabel.textColor = .red
    }
    
    func clearFields(){
        firstNameTextField.text = ""
        lastNameTextField.text = ""
        countryTextField.text = ""
        ageTextField.text = ""
        textView.text = ""
       
    }
    
    @IBAction func addTextView(_ sender : Any){
        
        guard let firstName = firstNameTextField.text,
              let lastName = lastNameTextField.text,
              let country = countryTextField.text,
              let age = ageTextField.text
        else{
            showErrorMessage("Invalid", "red")
            return
        }
        
        textView.text = String("Full Name: \(firstName) \(lastName) \nCountry: \(country) \nAge: \(age)")
    }
    
    @IBAction func submitButton(_ sender : Any){
        if let firstName = 	firstNameTextField.text, !firstName.isEmpty,
           let lastName =   lastNameTextField.text, !lastName.isEmpty,
           let country =   countryTextField.text, !country.isEmpty,
           let age =     ageTextField.text, !age.isEmpty
        {
            messageLabel.text = "Successfully Submitted!"
            messageLabel.textColor = .green
            
           clearFields()

        }
        else {
            showErrorMessage("Complete missing information", "red")

        }
    }
    
    @IBAction func clearButton(_ sender : UIButton){
        clearFields()
    }
}

