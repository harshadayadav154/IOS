//
//  ViewController.swift
//  IOSTest
//
//  Created by user235622 on 9/14/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBOutlet var myText : UITextField!
    @IBOutlet var myLabel : UILabel!
    var value: Int = 1

    @IBAction func step2(_ sender : UIButton){
        value = 2
    }
    
    @IBAction
    func clickButton(_ sender : UIButton){
        let i : Int = Int(myLabel!.text! as String) ?? 0
        myLabel.text = String(i+value);
    }
    
    @IBAction func decrement(_ sender: UIButton){
        let i : Int = Int(myLabel!.text! as String) ?? 0
        myLabel.text = String(i-value);
    }
    
    @IBAction func reset(_ sender: UIButton){
        myLabel.text = "0";
        value=1
    }
    
}

