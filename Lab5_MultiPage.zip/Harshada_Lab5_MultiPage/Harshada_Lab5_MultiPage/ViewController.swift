//
//  ViewController.swift
//  Harshada_Lab5_MultiPage
//
//  Created by user235622 on 10/5/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

