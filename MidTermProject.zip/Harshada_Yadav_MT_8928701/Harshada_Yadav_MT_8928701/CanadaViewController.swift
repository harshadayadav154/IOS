//
//  CanadaViewController.swift
//  Harshada_Yadav_MT_8928701
//
//  Created by user235622 on 11/3/23.
//

import UIKit

class CanadaViewController: UIViewController {
    
    @IBOutlet weak var cityImage: UIImageView!
    
    @IBOutlet weak var cityInput: UITextField!
    
    @IBOutlet weak var errorMessage: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        cityImage.image = UIImage(named: "Canada")
        
    }
    
    // Tap gesture
    @IBAction func tapMade(_ sender: Any) {
        if cityInput.isFirstResponder {
            cityInput.resignFirstResponder()
               }
    }
    
    
    // Find city
    @IBAction func findCity(_ sender: UIButton) {
        errorMessage.text = ""
        let imageName: String? = cityInput.text?.filter { !$0.isWhitespace }
               guard let image = UIImage(named: imageName!) else{
                   errorMessage.text = "Please enter correct city"
                   return
               }
        cityImage.image = image
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
