//
//  Lab2ViewController.swift
//  Harshada_Yadav_MT_8928701
//
//  Created by user235622 on 11/3/23.
//

import UIKit

class Lab2ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    @IBOutlet var myLabel : UILabel!
    var value: Int = 1

    // Increment or decrement by 2
    @IBAction func step2(_ sender : UIButton){
        value = 2
    }
    
    // Increment
    @IBAction
    func clickButton(_ sender : UIButton){
        let i : Int = Int(myLabel!.text! as String) ?? 0
        myLabel.text = String(i+value);
    }
    
    
    // Descrement value
    @IBAction func decrement(_ sender: UIButton){
        let i : Int = Int(myLabel!.text! as String) ?? 0
        myLabel.text = String(i-value);
    }
    
    
    // Reset the value to 0
    @IBAction func reset(_ sender: UIButton){
        myLabel.text = "0";
        value=1
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
