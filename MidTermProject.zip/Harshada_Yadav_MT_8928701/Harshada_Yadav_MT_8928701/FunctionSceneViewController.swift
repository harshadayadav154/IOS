//
//  FunctionSceneViewController.swift
//  Harshada_Yadav_MT_8928701
//
//  Created by user235622 on 11/3/23.
//

import UIKit

class FunctionSceneViewController: UIViewController {

    @IBOutlet weak var aTextField: UITextField!
    
    @IBOutlet weak var bTextField: UITextField!
    
    
    @IBOutlet weak var cTextField: UITextField!
    
    
    @IBOutlet weak var xResult: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    // Appear and disappear code
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
            self.view.endEditing(true)
        }
        func textFieldShouldReturn(_ textField: UITextField) -> Bool {
            self.view.endEditing(true)
            return false
        }
    
    // To calculate value of x
    @IBAction func calculateButton(_ sender: UIButton) {
            if let a = Double(aTextField.text ?? ""), let b = Double(bTextField.text ?? ""), let c = Double(cTextField.text ?? "") {
                    let discriminant = b * b - 4 * a * c

                if discriminant < 0 {
                    xResult.text = "There are no results as the discriminant is lesser than zero."
                             } else if discriminant == 0 {
                             
                                 let x = -b / (2 * a)
                                 xResult.text = "There is only one value for Variable X. \n X = \(x)"
                             } else {
                                 let x1 = (-b + sqrt(discriminant)) / (2 * a)
                                 let x2 = (-b - sqrt(discriminant)) / (2 * a)
                                 xResult.text = "There are two values for the Variable X. \n X1: " + String(format: "%.2f", x1) + ", X2: " + String(format: "%.2f", x2)
                               
                             }
                         } else {
                             xResult.text = "Enter a value for A, B, and C."
                             
                         }
        
    }
        
        // to clear all fields
        @IBAction func clearButton(_ sender: UIButton) {
            aTextField.text = ""
            bTextField.text = ""
            cTextField.text = ""
            
            xResult.text = "Enter a value for A, B and C to find X"
            
        }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
