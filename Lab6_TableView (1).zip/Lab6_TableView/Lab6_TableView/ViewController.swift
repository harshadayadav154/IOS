//
//  ViewController.swift
//  Lab6_TableView
//
//  Created by user235622 on 10/12/23.
//

import UIKit

class ViewController: UITableViewController {
    var toDoItems = ["Cooking","Do groccery", "Assignment","Complete Quiz"]
    
    
    @IBOutlet weak var addNewItems: UIBarButtonItem!
    override func viewDidLoad() {
        super.viewDidLoad()
        if let items = UserDefaults.standard.array(forKey: "ToDoList") as? [String] {
                   toDoItems = items
               }
        tableView.delegate = self
        tableView.dataSource = self
        // Do any additional setup after loading the view.
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return toDoItems.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath)-> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "myCell", for: indexPath) as! UITableViewCell
        cell.textLabel?.text = toDoItems[indexPath.row]
        return cell
    }
    
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
     if editingStyle == .delete {
      toDoItems.remove(at: indexPath.row)
         self.tableView.deleteRows(at: [indexPath], with: .fade)
         // Remove item from UserDefaults
        UserDefaults.standard.set(toDoItems, forKey: "ToDoList")
    }
    }
    
    
    @IBAction func addNewItem(_ sender: Any) {
        // Present an alert controller with a text field
        let alert = UIAlertController(title: "Add Item", message: "Add Item", preferredStyle: .alert)
        
         alert.addTextField { (textField)in
        textField.placeholder = "Take out trash"
        
        }

        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        alert.addAction(UIAlertAction(title: "Save", style: .default,handler: { (_) in
        guard let toDotext = alert.textFields?.first?.text else{
         return
        }
       
            self.toDoItems.append(toDotext)
        self.tableView.reloadData()
            // Save to UserDefaults
                            UserDefaults.standard.set(self.toDoItems, forKey: "ToDoList")
        
        }))
         present(alert,animated: true)
        
    }
}
