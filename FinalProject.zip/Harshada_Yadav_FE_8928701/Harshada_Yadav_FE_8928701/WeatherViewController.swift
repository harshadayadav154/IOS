//
//  WeatherViewController.swift
//  Harshada_Yadav_FE_8928701
//
//  Created by user235622 on 12/8/23.
//

import UIKit
import CoreLocation

class WeatherViewController: UIViewController, UITabBarDelegate, CLLocationManagerDelegate {
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    @IBOutlet var tabBar : UITabBar!
    
    var vc1 : UITableViewController?
    var vc2 : UIViewController?
    var vc3 : UIViewController?
    
    var destination: String?
    
    @IBOutlet weak var cityLabel: UILabel!
        @IBOutlet weak var weatherDescription: UILabel!
        @IBOutlet weak var weatherIconImage: UIImageView!
        @IBOutlet weak var temperatureLabel: UILabel!
        @IBOutlet weak var humidityLabel: UILabel!
        @IBOutlet weak var windSpeedLabel: UILabel!

        let locationManager = CLLocationManager()

        override func viewDidLoad() {
           
            super.viewDidLoad()

            // Do any additional setup after loading the view.
            
                    // Access the destination value
            if let destination = self.destination {
                print(destination)
                getWeatherData(for: destination)
                        }

            locationManager.delegate = self
            locationManager.requestWhenInUseAuthorization()
            locationManager.startUpdatingLocation()
        }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @IBAction func addDestinationButton(_ sender: Any) {
        // Present an alert controller with a text field
        let alert = UIAlertController(title: "Where would you like to go", message: "Enter your destination", preferredStyle: .alert)
        
         alert.addTextField { (textField)in
        textField.placeholder = ""
        
        }
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        alert.addAction(UIAlertAction(title: "Go", style: .default) { [weak self] _ in
            if let textField = alert.textFields?.first, let newCity = textField.text {
                self?.destination = newCity
                if let unwrappedDestination = self?.destination {
                    self?.getWeatherData(for: unwrappedDestination)
                }
                
            }
        })
       
         present(alert,animated: true)
        
    }
    
    func getWeatherData(for destination: String?) {
        // Ensure that destination is not nil before proceeding
            guard let unwrappedDestination = destination else {
                print("Destination is nil. Cannot fetch news data.")
                return
            }
            let apiKey = "26227272dbe78a66fd12f2314e336593"
            let urlString = "https://api.openweathermap.org/data/2.5/weather?q=\(unwrappedDestination)&appid=\(apiKey)"
            print(unwrappedDestination)
                    guard let url = URL(string: urlString) else { return }
                    let task = URLSession.shared.dataTask(with: url) { data, response, error in
                        if let data = data {
                            do {
                                let weatherData = try JSONDecoder().decode(WeatherData.self, from: data)
                                print(weatherData)
                                DispatchQueue.main.async {
                                                  self.updateUI(with: weatherData)
                                            }
                            } catch {
                                print("ERROR")
                            }
                        }
                    }
                    task.resume()
       }

        func updateUI(with weatherData: WeatherData) {
            cityLabel.text = weatherData.name
            weatherDescription.text = weatherData.weather.first?.description
            weatherIconImage.image = WeatherIcon.getIcon(for: weatherData.weather.first?.icon)
            let temperatureInCelsius = Int(weatherData.main.temp - 273.15)
                temperatureLabel.text = "\(temperatureInCelsius)°C"
            humidityLabel.text = "\(weatherData.main.humidity)%"
            let windInKm = weatherData.wind.speed * 3.6
            windSpeedLabel.text = String(format: "%.2f Km/h", windInKm)
        }
    
    func navigateToNewsScreen(with destination: String? = nil) {
            // Navigate to the News screen
            let newsViewController = storyboard?.instantiateViewController(withIdentifier: "NewsViewController") as! NewsViewController
            newsViewController.destination = destination
        navigationController?.setNavigationBarHidden(false, animated: false)
            navigationController?.pushViewController(newsViewController, animated: true)
        
        }
    func navigateToDirectionsScreen(with destination: String? = nil) {
            // Navigate to the Directions screen (Replace "DirectionsViewController" with your actual view controller name)
            let directionsViewController = storyboard?.instantiateViewController(withIdentifier: "DirectionsViewController") as! DirectionsViewController
        directionsViewController.destination = destination
        navigationController?.setNavigationBarHidden(true, animated: false)
            navigationController?.pushViewController(directionsViewController, animated: true)
        }

        func navigateToWeatherScreen(with destination: String? = nil) {
            // Navigate to the Weather screen (Replace "WeatherViewController" with your actual view controller name)
            let weatherViewController = storyboard?.instantiateViewController(withIdentifier: "WeatherViewController") as! WeatherViewController
            weatherViewController.destination = destination
            
            navigationController?.pushViewController(weatherViewController, animated: true)
        }
    
    func navigateToHistoryScreen(with destination: String? = nil) {
        // Navigate to the Weather screen (Replace "WeatherViewController" with your actual view controller name)
        let historyViewController = storyboard?.instantiateViewController(withIdentifier: "HistoryViewController") as! HistoryViewController
        
       
        navigationController?.pushViewController(historyViewController, animated: true)
    }


    func tabBar(_ tabBar: UITabBar, didSelect item: UITabBarItem) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        print(item.tag)
        switch(item.tag) {
        case 1:
            if vc1 == nil {
                saveTransaction(source: "Weather", type: "News")
                self.navigateToNewsScreen()
            }
        case 2:
            if vc2 == nil {
                saveTransaction(source: "Weather", type: "Direction")
                self.navigateToDirectionsScreen()
            }
        case 3:
            if vc3 == nil {
                saveTransaction(source: "Weather", type: "Weather")
                self.navigateToWeatherScreen()
            }
        default:
            break;
        }
    }
    
    // Function to save a transaction
       func saveTransaction(source: String, type: String) {
           let newTransaction = Transactions(context: context)
           newTransaction.source = source
           newTransaction.type = type

           do {
               try context.save()
               print("Transaction saved successfully!")
           } catch {
               print("Error saving transaction: \(error)")
           }
       }
    }

    struct WeatherData: Codable {
        let name: String
        let weather: [Weather]
        let main: Main
        let wind: Wind
    }

    struct Weather: Codable {
        let description: String
        let icon: String
    }

    struct Main: Codable {
        let temp: Double
        let humidity: Double
    }

    struct Wind: Codable {
        let speed: Double
    }

class WeatherIcon{
    static func getIcon(for weatherCode: String?) -> UIImage? {
        guard let weatherCode = weatherCode else {
            return nil
        }

        switch weatherCode {
        case "01d":
            return UIImage(named: "clear_day")
        case "01n":
            return UIImage(named: "clear_night")
        case "02d":
            return UIImage(named: "partly_cloudy_day")
        case "02n":
            return UIImage(named: "partly_cloudy_night")
        case "03d", "03n":
            return UIImage(named: "cloudy")
        case "04d", "04n":
            return UIImage(named: "broken_clouds")
        case "09d", "09n":
            return UIImage(named: "rainy")
        case "10d":
            return UIImage(named: "rainy_sun_day")
        case "10n":
            return UIImage(named: "rainy_sun_night")
        case "11d", "11n":
            return UIImage(named: "thunderstorm")
        case "13d", "13n":
            return UIImage(named: "snowy")
        case "50d", "50n":
            return UIImage(named: "foggy")
        default:
            return UIImage(named: "default")
        }
    }
}
