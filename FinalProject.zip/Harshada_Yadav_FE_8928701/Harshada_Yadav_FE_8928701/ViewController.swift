//
//  ViewController.swift
//  Harshada_Yadav_FE_8928701
//
//  Created by user235622 on 12/8/23.
//

import UIKit
import CoreData

class ViewController: UIViewController,UITabBarDelegate {
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    @IBOutlet var tabBar : UITabBar!
    
    var vc1 : UITableViewController?
    var vc2 : UIViewController?
    var vc3 : UIViewController?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        navigationController?.setNavigationBarHidden(false, animated: false)
      
    }
    		
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @IBAction func SearchHistory(_ sender: Any) {
        self.navigateToHistoryScreen()
    }
    @IBAction func pressButton(_ sender: Any) {
        // Present an alert controller with a text field
        let alert = UIAlertController(title: "Where would you like to go", message: "Enter your destination", preferredStyle: .alert)
        
         alert.addTextField { (textField)in
        textField.placeholder = ""
        
        }
        alert.addAction(UIAlertAction(title: "News", style: .default){ [weak self] _ in
            self?.navigateToNewsScreen(with: alert.textFields?.first?.text)
        })
        alert.addAction(UIAlertAction(title: "Directions", style: .default){ [weak self] _ in
            self?.navigateToDirectionsScreen(with: alert.textFields?.first?.text)
        })
        alert.addAction(UIAlertAction(title: "Weather", style: .default){ [weak self] _ in
            self?.navigateToWeatherScreen(with: alert.textFields?.first?.text)
        })
         present(alert,animated: true)
        
    }
    
    func navigateToNewsScreen(with destination: String? = nil) {
            // Navigate to the News screen
            let newsViewController = storyboard?.instantiateViewController(withIdentifier: "NewsViewController") as! NewsViewController
            newsViewController.destination = destination
      
            navigationController?.pushViewController(newsViewController, animated: true)
        
        }
    func navigateToDirectionsScreen(with destination: String? = nil) {
            // Navigate to the Directions screen (Replace "DirectionsViewController" with your actual view controller name)
            let directionsViewController = storyboard?.instantiateViewController(withIdentifier: "DirectionsViewController") as! DirectionsViewController
        directionsViewController.destination = destination
        navigationController?.setNavigationBarHidden(true, animated: false)
            navigationController?.pushViewController(directionsViewController, animated: true)
        }

        func navigateToWeatherScreen(with destination: String? = nil) {
            // Navigate to the Weather screen (Replace "WeatherViewController" with your actual view controller name)
            let weatherViewController = storyboard?.instantiateViewController(withIdentifier: "WeatherViewController") as! WeatherViewController
            weatherViewController.destination = destination
            navigationController?.setNavigationBarHidden(true, animated: false)
            navigationController?.pushViewController(weatherViewController, animated: true)
        }
    
    func navigateToHistoryScreen(with destination: String? = nil) {
        // Navigate to the Weather screen (Replace "WeatherViewController" with your actual view controller name)
        let historyViewController = storyboard?.instantiateViewController(withIdentifier: "HistoryViewController") as! HistoryViewController
        
       
        navigationController?.pushViewController(historyViewController, animated: true)
    }


    func tabBar(_ tabBar: UITabBar, didSelect item: UITabBarItem) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        print(item.tag)
        switch(item.tag) {
        case 1:
            if vc1 == nil {
                saveTransaction(source: "Alert", type: "News")
                self.navigateToNewsScreen()
            }
        case 2:
            if vc2 == nil {
                saveTransaction(source: "Alert", type: "Direction")
                self.navigateToDirectionsScreen()
            }
        case 3:
            if vc3 == nil {
                saveTransaction(source: "Alert", type: "Weather")
                self.navigateToWeatherScreen()
            }
        default:
            break;
        }
    }
    // Function to save a transaction
       func saveTransaction(source: String, type: String) {
           let newTransaction = Transactions(context: context)
           newTransaction.source = source
           newTransaction.type = type

           do {
               try context.save()
               print("Transaction saved successfully!")
           } catch {
               print("Error saving transaction: \(error)")
           }
       }

}

