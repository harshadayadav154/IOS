//
//  NewsViewController.swift
//  Harshada_Yadav_FE_8928701
//
//  Created by user235622 on 12/8/23.
//

import UIKit

class NewsViewController: UITableViewController,UITabBarDelegate {
    var destination: String?
    var newsData: [NewsItem] = []
    override func viewDidLoad() {
       
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        print("here")
                // Access the destination value
        if let destination = destination {
                       
            getNewsData(for: destination)
                    }
        // Set up the table view
                tableView.dataSource = self
                tableView.delegate = self
    }
    @IBAction func addDestinationButton(_ sender: Any) {
        // Present an alert controller with a text field
        let alert = UIAlertController(title: "Where would you like to go", message: "Enter your destination", preferredStyle: .alert)
        
         alert.addTextField { (textField)in
        textField.placeholder = ""
        
        }
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        alert.addAction(UIAlertAction(title: "Go", style: .default) { [weak self] _ in
            if let textField = alert.textFields?.first, let newCity = textField.text {
                self?.destination = newCity
                if let unwrappedDestination = self?.destination {
                    self?.getNewsData(for: unwrappedDestination)
                }
                
            }
        })
       
         present(alert,animated: true)
        
    }
    
    
    func getNewsData (for destination: String?){
        // Ensure that destination is not nil before proceeding
            guard let unwrappedDestination = destination else {
                print("Destination is nil. Cannot fetch news data.")
                return
            }

        let apiKey = "788080957edb492e8c4b00b9adda5ba2"
        let urlString = "https://newsapi.org/v2/everything?q=\(unwrappedDestination)&apiKey=\(apiKey)"
        guard let url = URL(string: urlString) else { return }
        let task = URLSession.shared.dataTask(with: url) { data, response, error in
                                if let data = data {
                                    do {
                                        let newsResponse = try JSONDecoder().decode(NewsResponse.self, from: data)
                                       
                                        DispatchQueue.main.async {
                                            self.newsData = newsResponse.articles
                                            self.tableView.reloadData()
                                                    }
                                    } catch {
                                        print("ERROR",error)
                                    }
                                }
                            }
                            task.resume()
    }
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return newsData.count
        }

       override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let cell = tableView.dequeueReusableCell(withIdentifier: "newsCell", for: indexPath) as! NewsCell
           
            let newsItem = newsData[indexPath.row]
           
            cell.titleLabel.text = newsItem.title
            cell.descriptionLabel.text = newsItem.description ?? "N/A"
            cell.authorLabel.text = "Author: \(newsItem.author ?? "N/A")"
            cell.sourceLabel.text = "Source: \(newsItem.source?.name ?? "N/A")"

            return cell
        }
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 250
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
   

}

class NewsCell: UITableViewCell {

    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var descriptionLabel: UILabel!
    @IBOutlet weak var authorLabel: UILabel!
    @IBOutlet weak var sourceLabel: UILabel!
}

struct NewsItem: Codable {
    var title: String
    var description: String?
    var author: String?
    var source: NewsSource?
    // Add other properties if needed
}

struct NewsSource: Codable {
    var name: String?
}

struct NewsResponse: Codable {
    var articles: [NewsItem]
}
