//
//  HistoryViewController.swift
//  Harshada_Yadav_FE_8928701
//
//  Created by user235622 on 12/11/23.
//
import UIKit
import CoreData

class HistoryViewController: UITableViewController {

   
    
    var transactions: [Transactions] = []

    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext

    override func viewDidLoad() {
        super.viewDidLoad()
        fetchTransactions()
        setupTableView()
    }

    func fetchTransactions() {
        let fetchRequest: NSFetchRequest<Transactions> = Transactions.fetchRequest()

        do {
            transactions = try context.fetch(fetchRequest)
            tableView.reloadData()
        } catch {
            print("Error fetching data: \(error)")
        }
    }

    func setupTableView() {
        tableView.dataSource = self
        tableView.delegate = self
        tableView.reloadData()
    }

    // MARK: - Table View Data Source

   override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return transactions.count
    }

   override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> HistoryCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "historyCell", for: indexPath) as! HistoryCell
        let transaction = transactions[indexPath.row]
        // Configure the cell with transaction data
        cell.sourceLabel?.text = transaction.source
        cell.typeLabel?.text = transaction.type
        return cell
    }
}


class HistoryCell: UITableViewCell {

    @IBOutlet weak var sourceLabel: UILabel!
    @IBOutlet weak var typeLabel: UILabel!
    
}
