//
//  DirectionsViewController.swift
//  Harshada_Yadav_FE_8928701
//
//  Created by user235622 on 12/8/23.
//

import UIKit
import MapKit

import CoreLocation

class DirectionsViewController: UIViewController, UITabBarDelegate,CLLocationManagerDelegate, MKMapViewDelegate  {
    @IBOutlet var tabBar : UITabBar!
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    var vc1 : UITableViewController?
    var vc2 : UIViewController?
    var vc3 : UIViewController?
    
    var destination: String?
    @IBOutlet weak var mapView: MKMapView!
    @IBOutlet weak var zoomSlider: UISlider!
    
    var locationManager = CLLocationManager()

    var startLocation: CLLocation?
    var destinationLocation: CLLocation?
    var selectedTravelMode: MKDirectionsTransportType = .automobile
    	
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
                mapView.delegate = self
                        configureLocationManager()
                        centerMapOnCurrentLocation()
                        addPinToCurrentLocation()
                
                // Set up the zoom slider
                       zoomSlider.minimumValue = 0.5
                       zoomSlider.maximumValue = 5.0
                       zoomSlider.value = 1.0
                       zoomSlider.addTarget(self, action: #selector(zoomSliderValueChanged), for: .valueChanged)
        if let destination = destination {
                 
                          // decoding coordinates for destination
                          geocodeCity(city: destination) { coordinates in
                              if let coordinates = coordinates {
                                  
                                  self.destinationLocation = CLLocation(latitude: coordinates.latitude, longitude: coordinates.longitude)
                                  self.updateMapView()
                                  self.addPin(at: coordinates, title: "Destination")
                                
                              } else {
                                  print("Geocoding failed or no location found.")
                              }
                          }
              }
    }
    
    // modeof travel is changed
    @IBAction func walkMode(_ sender: Any) {
        self.selectedTravelMode = .walking
        self.updateMapView()
    }
    @IBAction func bikeMode(_ sender: Any) {
        self.selectedTravelMode = .automobile
        self.updateMapView()
    }
    @IBAction func carMode(_ sender: Any) {
        self.selectedTravelMode = .automobile
        self.updateMapView()
    }
    
    // change destinationa
    @IBAction func addDestinationButton(_ sender: Any) {
        // Present an alert controller with a text field
        let alert = UIAlertController(title: "Where would you like to go", message: "Enter your destination", preferredStyle: .alert)
        
         alert.addTextField { (textField)in
        textField.placeholder = ""
        
        }
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        alert.addAction(UIAlertAction(title: "Go", style: .default) { [weak self] _ in
            if let textField = alert.textFields?.first, let newCity = textField.text {
                self?.destination = newCity
                if let unwrappedDestination = self?.destination {
                    self?.geocodeCity(city: unwrappedDestination) { coordinates in
                        if let coordinates = coordinates {
                            print("here")
                            self?.destinationLocation = CLLocation(latitude: coordinates.latitude, longitude: coordinates.longitude)
                            self?.updateMapView()
                            self?.addPin(at: coordinates, title: "Destination")
                           
                            
                            // Now you can safely use coordinates.latitude and coordinates.longitude
                        } else {
                            print("Geocoding failed or no location found.")
                        }
                    }

                }
                
            }
        })
       
         present(alert,animated: true)
        
    }
    @objc func zoomSliderValueChanged() {
                   let zoomLevel = Double(zoomSlider.value)
                   let region = MKCoordinateRegion(center: mapView.centerCoordinate, latitudinalMeters: 1000 * zoomLevel, longitudinalMeters: 1000 * zoomLevel)
                   mapView.setRegion(region, animated: true)
               }

            
            func configureLocationManager() {
                   locationManager.delegate = self
                   locationManager.desiredAccuracy = kCLLocationAccuracyBest
                   locationManager.requestWhenInUseAuthorization()
                   locationManager.startUpdatingLocation()
               }

               func centerMapOnCurrentLocation() {
                   if let userLocation = locationManager.location?.coordinate {
                       let region = MKCoordinateRegion(center: userLocation, latitudinalMeters: 1000, longitudinalMeters: 1000)
                       mapView.setRegion(region, animated: true)
                   }
               }
            
            func addPinToCurrentLocation() {
                    if let userLocation = locationManager.location?.coordinate {
                        self.startLocation = CLLocation(latitude: userLocation.latitude, longitude: userLocation.longitude)
                        addPin(at: userLocation, title: "Current Location")
                    }
                }
           // Add pin and route to destination
            func addPinsAndRoute() {
                
                guard let startLocation = self.startLocation, let endLocation = self.destinationLocation else {
                    return
                }
           
                let sourcePlacemark = MKPlacemark(coordinate: startLocation.coordinate)
                let destinationPlacemark = MKPlacemark(coordinate: endLocation.coordinate)

                   let sourceItem = MKMapItem(placemark: sourcePlacemark)
                   let destinationItem = MKMapItem(placemark: destinationPlacemark)
                
               
                
                let request = MKDirections.Request()
                request.source = sourceItem
                request.destination = destinationItem
                request.transportType = .automobile
                
                let directions = MKDirections(request: request)
                
                directions.calculate { [weak self] (response, error) in
                    if let error = error {
                                    print("Error calculating directions: \(error.localizedDescription)")
                                    return
                                }
                    
                    if let route = response?.routes.first {
                        self?.mapView.addOverlay(route.polyline, level: .aboveRoads)
                        
                        // Adjust zoom to fit both start and end locations
                        let edgePadding = UIEdgeInsets(top: 20, left: 20, bottom: 20, right: 20)
                        self?.mapView.setVisibleMapRect(route.polyline.boundingMapRect, edgePadding: edgePadding, animated: true)
                    }
                }
            
                }
                

                func addPin(at coordinate: CLLocationCoordinate2D, title: String) {
                    let annotation = MKPointAnnotation()
                    annotation.coordinate = coordinate
                    annotation.title = title
                    mapView.addAnnotation(annotation)
                }

                func addPolyline(from startCoordinate: CLLocationCoordinate2D, to endCoordinate: CLLocationCoordinate2D) {
                    let coordinates = [startCoordinate, endCoordinate]
                    let polyline = MKPolyline(coordinates: coordinates, count: coordinates.count)
                    mapView.addOverlay(polyline)
                }

            
            func geocodeCity(city: String, completion: @escaping (CLLocationCoordinate2D?) -> Void) {
                let geocoder = CLGeocoder()

                geocoder.geocodeAddressString(city) { placemarks, error in
                    if let error = error {
                        print("Geocoding error: \(error.localizedDescription)")
                        completion(nil)
                        return
                    }

                    if let placemark = placemarks?.first,
                       let location = placemark.location?.coordinate {
                        completion(location)
                    } else {
                        print("No location found for the city: \(city)")
                        completion(nil)
                    }
                }
            }
            
            func updateMapView() {
                // Remove existing annotations and polyline
                mapView?.removeAnnotations(mapView.annotations)
                mapView?.removeOverlays(mapView.overlays)
                
                // Add new pins and polyline
                addPinsAndRoute()
            }
    
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        if let polyline = overlay as? MKPolyline {
            let renderer = MKPolylineRenderer(polyline: polyline)
            renderer.strokeColor = UIColor.blue // Set the stroke color here
            renderer.lineWidth = 3
            return renderer
        }
        return MKOverlayRenderer(overlay: overlay)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    func navigateToNewsScreen(with destination: String? = nil) {
            // Navigate to the News screen
            let newsViewController = storyboard?.instantiateViewController(withIdentifier: "NewsViewController") as! NewsViewController
            newsViewController.destination = destination
        navigationController?.setNavigationBarHidden(false, animated: false)
            navigationController?.pushViewController(newsViewController, animated: true)
        
        }
    func navigateToDirectionsScreen(with destination: String? = nil) {
            // Navigate to the Directions screen (Replace "DirectionsViewController" with your actual view controller name)
            let directionsViewController = storyboard?.instantiateViewController(withIdentifier: "DirectionsViewController") as! DirectionsViewController
        directionsViewController.destination = destination
        
            navigationController?.pushViewController(directionsViewController, animated: true)
        }

        func navigateToWeatherScreen(with destination: String? = nil) {
            // Navigate to the Weather screen (Replace "WeatherViewController" with your actual view controller name)
            let weatherViewController = storyboard?.instantiateViewController(withIdentifier: "WeatherViewController") as! WeatherViewController
            weatherViewController.destination = destination
            navigationController?.setNavigationBarHidden(true, animated: false)
            navigationController?.pushViewController(weatherViewController, animated: true)
        }

    func tabBar(_ tabBar: UITabBar, didSelect item: UITabBarItem) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        print(item.tag)
        switch(item.tag) {
        case 1:
            if vc1 == nil {
                saveTransaction(source: "Directions", type: "News")
                print("here directions")
                self.navigateToNewsScreen()
            }
        case 2:
            if vc2 == nil {
                saveTransaction(source: "Directions", type: "Direction")
                self.navigateToDirectionsScreen()
            }
        case 3:
            if vc3 == nil {
                saveTransaction(source: "Directions", type: "Weather")
                self.navigateToWeatherScreen()
            }
        default:
            break;
        }
    }
    
    // Function to save a transaction
       func saveTransaction(source: String, type: String) {
           let newTransaction = Transactions(context: context)
           newTransaction.source = source
           newTransaction.type = type

           do {
               try context.save()
               print("Transaction saved successfully!")
           } catch {
               print("Error saving transaction: \(error)")
           }
       }

}


