//
//  MapInteraction+CoreDataClass.swift
//  Harshada_Yadav_FE_8928701
//
//  Created by user235622 on 12/11/23.
//
//

import Foundation
import CoreData

@objc(MapInteraction)
public class MapInteraction: NSManagedObject {

}
