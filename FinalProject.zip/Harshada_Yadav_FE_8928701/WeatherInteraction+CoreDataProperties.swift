//
//  WeatherInteraction+CoreDataProperties.swift
//  Harshada_Yadav_FE_8928701
//
//  Created by user235622 on 12/11/23.
//
//

import Foundation
import CoreData


extension WeatherInteraction {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<WeatherInteraction> {
        return NSFetchRequest<WeatherInteraction>(entityName: "WeatherInteraction")
    }

    @NSManaged public var dateTime: Date?
    @NSManaged public var humidity: String?
    @NSManaged public var speed: Double
    @NSManaged public var temp: Double

}

extension WeatherInteraction : Identifiable {

}
