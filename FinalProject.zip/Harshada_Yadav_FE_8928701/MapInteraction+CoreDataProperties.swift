//
//  MapInteraction+CoreDataProperties.swift
//  Harshada_Yadav_FE_8928701
//
//  Created by user235622 on 12/11/23.
//
//

import Foundation
import CoreData


extension MapInteraction {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<MapInteraction> {
        return NSFetchRequest<MapInteraction>(entityName: "MapInteraction")
    }

    @NSManaged public var distanceTravelled: Int32
    @NSManaged public var endLocation: String?
    @NSManaged public var modeOfTravel: String?
    @NSManaged public var startLocation: String?

}

extension MapInteraction : Identifiable {

}
