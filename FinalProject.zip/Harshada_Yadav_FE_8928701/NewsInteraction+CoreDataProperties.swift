//
//  NewsInteraction+CoreDataProperties.swift
//  Harshada_Yadav_FE_8928701
//
//  Created by user235622 on 12/11/23.
//
//

import Foundation
import CoreData


extension NewsInteraction {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<NewsInteraction> {
        return NSFetchRequest<NewsInteraction>(entityName: "NewsInteraction")
    }

    @NSManaged public var author: String?
    @NSManaged public var newsDescription: String?
    @NSManaged public var source: String?
    @NSManaged public var title: String?

}

extension NewsInteraction : Identifiable {

}
