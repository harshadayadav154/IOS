//
//  ViewController.swift
//  Lab3_AutoLayout
//
//  Created by user235622 on 9/28/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

