//
//  ViewController.swift
//  Lab8_Networking
//
//  Created by user235622 on 11/14/23.
//

import UIKit
import CoreLocation

class ViewController: UIViewController,CLLocationManagerDelegate {

    
    @IBOutlet weak var cityLabel: UILabel!
        @IBOutlet weak var weatherDescription: UILabel!
        @IBOutlet weak var weatherIconImage: UIImageView!
        @IBOutlet weak var temperatureLabel: UILabel!
        @IBOutlet weak var humidityLabel: UILabel!
        @IBOutlet weak var windSpeedLabel: UILabel!

        let locationManager = CLLocationManager()

        override func viewDidLoad() {
            super.viewDidLoad()

            locationManager.delegate = self
            locationManager.requestWhenInUseAuthorization()
            locationManager.startUpdatingLocation()
        }

        func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
            guard let location = locations.last else { return }
            getWeatherData(latitude: location.coordinate.latitude, longitude: location.coordinate.longitude)
            
            locationManager.stopUpdatingLocation()
        }

        func getWeatherData(latitude: CLLocationDegrees, longitude: CLLocationDegrees) {
            let apiKey = "26227272dbe78a66fd12f2314e336593"
            let urlString = "https://api.openweathermap.org/data/2.5/weather?lat=\(latitude)&lon=\(longitude)&appid=\(apiKey)"
            
                                guard let url = URL(string: urlString) else { return }
                    let task = URLSession.shared.dataTask(with: url) { data, response, error in
                        if let data = data {
                            do {
                                let weatherData = try JSONDecoder().decode(WeatherData.self, from: data)
                                print(weatherData)
                                DispatchQueue.main.async {
                                                  self.updateUI(with: weatherData)
                                            }
                            } catch {
                                print("ERROR")
                            }
                        }
                    }
                    task.resume()
       }

        func updateUI(with weatherData: WeatherData) {
            cityLabel.text = weatherData.name
            weatherDescription.text = weatherData.weather.first?.description
            weatherIconImage.image = WeatherIcon.getIcon(for: weatherData.weather.first?.icon)
            let temperatureInCelsius = Int(weatherData.main.temp - 273.15)
                temperatureLabel.text = "\(temperatureInCelsius)°C"
            humidityLabel.text = "\(weatherData.main.humidity)%"
            let windInKm = weatherData.wind.speed * 3.6
            windSpeedLabel.text = String(format: "%.2f Km/h", windInKm)
        }
    }

    struct WeatherData: Codable {
        let name: String
        let weather: [Weather]
        let main: Main
        let wind: Wind
    }

    struct Weather: Codable {
        let description: String
        let icon: String
    }

    struct Main: Codable {
        let temp: Double
        let humidity: Double
    }

    struct Wind: Codable {
        let speed: Double
    }

class WeatherIcon{
    static func getIcon(for weatherCode: String?) -> UIImage? {
        guard let weatherCode = weatherCode else {
            return nil
        }

        switch weatherCode {
        case "01d":
            return UIImage(named: "clear_day")
        case "01n":
            return UIImage(named: "clear_night")
        case "02d":
            return UIImage(named: "partly_cloudy_day")
        case "02n":
            return UIImage(named: "partly_cloudy_night")
        case "03d", "03n":
            return UIImage(named: "cloudy")
        case "04d", "04n":
            return UIImage(named: "broken_clouds")
        case "09d", "09n":
            return UIImage(named: "rainy")
        case "10d":
            return UIImage(named: "rainy_sun_day")
        case "10n":
            return UIImage(named: "rainy_sun_night")
        case "11d", "11n":
            return UIImage(named: "thunderstorm")
        case "13d", "13n":
            return UIImage(named: "snowy")
        case "50d", "50n":
            return UIImage(named: "foggy")
        default:
            return UIImage(named: "default")
        }
    }
}

