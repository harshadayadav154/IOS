//
//  ViewController.swift
//  Lab7GPS
//
//  Created by user235622 on 11/8/23.
//

import UIKit
import MapKit

import CoreLocation

class ViewController: UIViewController,CLLocationManagerDelegate, MKMapViewDelegate {
    
    // Outlets
        @IBOutlet weak var currentSpeedLabel: UILabel!
        @IBOutlet weak var maxSpeedLabel: UILabel!
        @IBOutlet weak var averageSpeedLabel: UILabel!
        @IBOutlet weak var distanceLabel: UILabel!
        @IBOutlet weak var maxAccelerationLabel: UILabel!
        @IBOutlet weak var topBarView: UIView!
        @IBOutlet weak var bottomBarView: UIView!
        @IBOutlet weak var mapView: MKMapView!
        
        // Variables
        var locationManager: CLLocationManager = CLLocationManager()
        var startLocation: CLLocation?
        var lastLocation: CLLocation?
        var maxSpeed: CLLocationSpeed = 0
        var totalDistance: CLLocationDistance = 0
        var startTime: Date?
        var totalAcceleration: Double = 0
        var maxAcceleration: Double = 0
        var previousSpeed: CLLocationSpeed?
        var speeds: [CLLocationSpeed] = []
        
        override func viewDidLoad() {
            super.viewDidLoad()
            
            // Initialize map elements
            locationManager.delegate = self
                   
            locationManager.requestWhenInUseAuthorization()
            locationManager.desiredAccuracy = kCLLocationAccuracyBest
            
        }
        
        @IBAction func startTripClick(_ sender: UIButton) {
            startTime = Date()
            mapView.showsUserLocation = true
            locationManager.startUpdatingLocation()
            updateUI()
        }
        
        @IBAction func stopTripClick(_ sender: UIButton) {
            locationManager.stopUpdatingLocation()
            mapView.showsUserLocation = false
            updateUI()
            bottomBarView.backgroundColor = .gray
        }
        
        
        func calculateAverageSpeed() -> CLLocationSpeed {
            guard !speeds.isEmpty else { return 0 }
                    let totalSpeed = speeds.reduce(0, +)
                    return totalSpeed / CLLocationSpeed(speeds.count)
        }
    
        func calculateAcceleration(currentSpeed: CLLocationSpeed) -> Double {
            guard let previousTime = startTime, let previousSpeed = previousSpeed else { return 0 }
            let timeElapsed = Date().timeIntervalSince(previousTime)
            let acceleration = ((currentSpeed - previousSpeed) / timeElapsed).magnitude
            if acceleration > maxAcceleration {
                maxAcceleration = acceleration
            }
            return acceleration
        }

        
        func updateUI() {
            guard let lastLocation = lastLocation, let startLocation = startLocation else { return }
            let currentSpeed = lastLocation.speed
            speeds.append(currentSpeed)
            currentSpeedLabel.text = String(format: "%.2f km/h", currentSpeed * 3.6)
            if currentSpeed > maxSpeed {
                maxSpeed = currentSpeed
                maxSpeedLabel.text = String(format: "%.2f km/h", maxSpeed * 3.6)
            }
            let distanceInKM = totalDistance / 1000
            distanceLabel.text = String(format: "%.2f km", distanceInKM)
            maxAccelerationLabel.text = String(format: "%.2f m/s^2", maxAcceleration)
            
            let averageSpeed = calculateAverageSpeed()
            averageSpeedLabel.text = String(format: "%.2f km/h", averageSpeed * 3.6)
            
            if currentSpeed > 115 / 3.6 {
                topBarView.backgroundColor = .red
            } else {
                topBarView.backgroundColor = .clear
            }
            
            if startLocation.coordinate.latitude != 0 && startLocation.coordinate.longitude != 0 {
                        bottomBarView.backgroundColor = .green
                    } else {
                        bottomBarView.backgroundColor = .gray
                    }
        }
        	
        func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
            guard let location = locations.last else { return }
            if startLocation == nil {
                startLocation = location
                lastLocation = location
                
            } else {
                guard let lastLocationUnwrapped = lastLocation else { return }
                            let distance = lastLocationUnwrapped.distance(from: location)
                            totalDistance += distance
                            let currentSpeed = location.speed
                            let acceleration = calculateAcceleration(currentSpeed: currentSpeed)
                            previousSpeed = currentSpeed
                            lastLocation = location
                
            }
            
            // Update map view
            // Zoom to the user's location
            let region = MKCoordinateRegion(center: location.coordinate, latitudinalMeters: 1000, longitudinalMeters: 1000)
            mapView.setRegion(region, animated: true)
            let annotation = MKPointAnnotation()
            annotation.coordinate = location.coordinate
            mapView.addAnnotation(annotation)
            
             mapView.setRegion(region, animated: true)
 
            updateUI()
        }
}

